The photos in `images/` are selected from the original project photos and were re-saved without EXIF metadata before publication.
