# Publishing this repository to GitHub

## Suggested repository name

`hp-chromebook-14-g7-fedora-linux`

## Suggested description

> Step-by-step guide to replacing ChromeOS on the HP Chromebook 14 G7 (DRAWMAN/Jasper Lake) with MrChromebox UEFI Full ROM and Fedora Xfce.

## Suggested visibility

Public, if you want the guide to be searchable and useful to other owners.

## Manual Git commands

Create an empty GitHub repository first, then from this folder run:

```bash
git init
git add .
git commit -m "Add HP Chromebook 14 G7 Fedora conversion guide"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/hp-chromebook-14-g7-fedora-linux.git
git push -u origin main
```

Replace `YOUR_USERNAME` with your GitHub username.

## Suggested topics

`chromebook`, `hp-chromebook`, `hp-chromebook-14-g7`, `drawman`, `jasper-lake`,
`linux`, `fedora`, `xfce`, `mrchromebox`, `coreboot`, `uefi`, `chrultrabook`

## License

No license has been added automatically. Before publishing, decide whether you want
others to be allowed to reuse/modify the guide and photos, then add an appropriate
license if desired.
